"""Validate all observer-control samples and reported installed identities."""
import hashlib
import json
from pathlib import Path
import statistics
import zipfile

BASE = Path('/tmp/phase5-observer-effect')
WHEEL = Path('/tmp/phase5-signal-state-final-wheels/ferrocopg-0.1.0-cp314-cp314-macosx_11_0_arm64.whl')
with zipfile.ZipFile(WHEEL) as archive:
    code = {name: hashlib.sha256(archive.read(name)).hexdigest()
            for name in archive.namelist()
            if name.startswith('ferrocopg/') and name.endswith(('.py', '.so', '.pyd'))}
assert json.loads((BASE / 'order.json').read_text()) == [
    {'name': name, 'status': 0}
    for name in ('plain-a', 'observed-a', 'observed-b', 'plain-b')]
pairs = {}
for order in ('a', 'b'):
    reports = {}
    for mode in ('plain', 'observed'):
        report = json.loads((BASE / f'{mode}-{order}.json').read_text())
        assert report['mode'] == 'integration-diagnostic'
        assert report['iterations'] == 25000 and len(report['samples']) == 3
        assert report['profile'] is None and report['acceptance_evidence'] is False
        assert report['bookkeeping'] == 'normal'
        assert report['installed_file_sha256']['ferrocopg'] == code
        assert report['medians_us'] == {key: statistics.median(r[key] for r in report['samples'])
                                        for key in ('wall_us', 'cpu_us')}
        reports[mode] = report['medians_us']
    activity = [json.loads(line) for line in (BASE / f'observed-{order}-activity.jsonl').read_text().splitlines()]
    assert activity[-1]['status'] == 'completed'
    assert activity[-1]['samples'] == len(activity)-2
    elapsed = sum(row['elapsed_seconds'] for row in activity[1:-1])
    pairs[order] = {'medians_us': reports,
                    'observed_over_plain': {key: reports['observed'][key]/reports['plain'][key]
                                           for key in ('wall_us', 'cpu_us')},
                    'observer_cpu_seconds': activity[-1]['observer_thread_cpu_seconds'],
                    'elapsed_seconds': elapsed,
                    'observer_one_core_percent': activity[-1]['observer_thread_cpu_seconds']/elapsed*100}
result = {'acceptance_evidence': False, 'pairs': pairs,
          'limitations': ['Short local diagnostic, not proof of zero observer effect.',
                          'Initial coordinator snapshot CPU excluded from observer-thread accounting.',
                          'No runtime performance claim or relaxed host-idleness requirement.']}
(BASE / 'audit.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
