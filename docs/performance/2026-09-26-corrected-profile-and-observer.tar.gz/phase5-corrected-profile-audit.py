"""Validate corrected-wheel profile identities and expose attribution limits."""
import hashlib
import json
from pathlib import Path
import pstats
import zipfile

ROOT = Path('/Users/martijnberger/src/psycopg')
OUT = Path('/tmp/phase5-corrected-integration-profile')
WHEEL = Path('/tmp/phase5-signal-state-final-wheels/ferrocopg-0.1.0-cp314-cp314-macosx_11_0_arm64.whl')
wheel_sha = hashlib.sha256(WHEEL.read_bytes()).hexdigest()
assert wheel_sha == '703a53605a39ab1571995d8013071fca6e65ea5dc0d9cc8645bca396ce982525'
with zipfile.ZipFile(WHEEL) as archive:
    code = {name: hashlib.sha256(archive.read(name)).hexdigest()
            for name in archive.namelist()
            if name.startswith('ferrocopg/') and name.endswith(('.py', '.so', '.pyd'))}
identities = {}
profiles = {}
for path in sorted(OUT.glob('*.json')):
    report = json.loads(path.read_text())
    assert report['mode'] == 'integration-profile'
    assert report['acceptance_evidence'] is False
    assert report['iterations'] == 10000 and report['warmup'] == 1000
    assert report['bookkeeping'] == 'normal' and report['omitted_helper_bodies'] == []
    assert report['binary'] is report['prepared'] is True
    assert report['metadata']['revision'].startswith('17c77760')
    backend = report['backend']
    fingerprints = report['installed_file_sha256']
    assert identities.setdefault(backend, fingerprints) == fingerprints
    if backend == 'rust':
        assert fingerprints['ferrocopg'] == code
    stats = pstats.Stats(report['profile'])
    functions = []
    for (filename, line, function), (primitive, calls, own, cumulative, callers) in stats.stats.items():
        functions.append({'file': filename, 'line': line, 'function': function,
                          'primitive_calls': primitive, 'calls': calls,
                          'self_seconds': own, 'cumulative_seconds': cumulative})
    operations = [f for f in functions if f['function'] == 'operation']
    assert len(operations) == 1 and operations[0]['calls'] == 10000
    profiles[path.stem] = {'report': report,
                           'profile_sha256': hashlib.sha256(Path(report['profile']).read_bytes()).hexdigest(),
                           'total_calls': stats.total_calls,
                           'profiled_seconds': stats.total_tt,
                           'functions': sorted(functions, key=lambda r: -r['cumulative_seconds'])}
    print(path.stem, stats.total_calls, round(stats.total_tt, 6))
assert len(profiles) == 8
result = {'candidate_wheel_sha256': wheel_sha, 'acceptance_evidence': False,
          'profiles': profiles, 'limitations': [
              'cProfile has implementation-dependent overhead; totals are not unprofiled latency or recoverable savings.',
              'C/PyO3 internals are opaque; a Python-visible call count is not total work.',
              'Cumulative functions overlap; do not sum nested regions.',
              'Local host not continuously observed during these profiles; not idle-host acceptance.',
              'No adaptation constructors, callback behavior, parser caches or production code changed.'
          ]}
(ROOT / 'docs/performance/2026-09-26-corrected-integration-profile.json').write_text(json.dumps(result, indent=2)+'\n')
