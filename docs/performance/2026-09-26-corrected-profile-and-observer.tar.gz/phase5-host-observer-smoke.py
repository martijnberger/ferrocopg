"""Exercise real host observation around a separate installed diagnostic worker."""
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/martijnberger/src/psycopg')
sys.path.insert(0, str(ROOT / 'tools/phase5'))
from host_activity import HostActivity

OUT = Path('/tmp/phase5-host-observer-smoke')
OUT.mkdir(exist_ok=False)
revision = subprocess.check_output(['jj', 'log', '-r', '17c77760', '--no-graph',
                                    '-T', 'commit_id'], cwd=ROOT, text=True).strip()
with HostActivity(OUT / 'host-activity.jsonl', interval=2.0):
    result = subprocess.run([
        sys.executable, str(ROOT / 'tools/phase5/integration_profile.py'),
        '--case', 'public-fresh', '--workload', 'parameterized',
        '--iterations', '25000', '--samples', '3', '--revision', revision,
        '--output', str(OUT / 'worker.json')], env=dict(os.environ), check=True)
records = [json.loads(line) for line in (OUT / 'host-activity.jsonl').read_text().splitlines()]
assert records[-1]['status'] == 'completed'
assert records[-1]['samples'] == len(records)-2
assert records[-1]['samples'] >= 2
print(json.dumps({'exit_status': result.returncode, 'observer': records[-1],
                  'intervals': [{'elapsed_seconds': r['elapsed_seconds'],
                                 'unavailable_processes': r['unavailable_processes']}
                                for r in records[1:-1]],
                  'acceptance_evidence': False}, indent=2))
