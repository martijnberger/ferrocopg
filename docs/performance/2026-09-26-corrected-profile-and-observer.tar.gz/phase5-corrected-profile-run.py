"""Sequential attribution on the frozen corrected release wheel, not timing acceptance."""
import os
from pathlib import Path
import subprocess

root = Path('/Users/martijnberger/src/psycopg')
out = Path('/tmp/phase5-corrected-integration-profile')
python = '/tmp/phase5-signal-state-env/bin/python'
revision = subprocess.check_output(
    ['jj', 'log', '-r', '17c77760', '--no-graph', '-T', 'commit_id'], cwd=root,
    text=True).strip()
for backend in ('rust', 'c'):
    for case in ('public-fresh', 'public-reused'):
        for workload in ('constant', 'parameterized'):
            name = f'{backend}-{case}-{workload}'
            command = [python, str(root / 'tools/phase5/integration_profile.py'),
                       '--backend', backend, '--case', case, '--workload', workload,
                       '--iterations', '10000', '--revision', revision,
                       '--output', str(out / f'{name}.json'),
                       '--profile', str(out / f'{name}.pstats')]
            print(name, flush=True)
            with (out / f'{name}.log').open('w') as log:
                result = subprocess.run(command, cwd=root, stdout=log,
                                        stderr=subprocess.STDOUT, timeout=90,
                                        env=dict(os.environ))
            if result.returncode:
                raise SystemExit(f'{name} failed with status {result.returncode}')
