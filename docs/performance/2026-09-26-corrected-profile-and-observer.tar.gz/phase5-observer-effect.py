"""Bounded both-order observer control on one frozen installed runtime."""
from contextlib import nullcontext
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/Users/martijnberger/src/psycopg')
sys.path.insert(0, str(ROOT / 'tools/phase5'))
from host_activity import HostActivity

OUT = Path('/tmp/phase5-observer-effect')
OUT.mkdir(exist_ok=False)
revision = subprocess.check_output(['jj', 'log', '-r', '17c77760', '--no-graph',
                                    '-T', 'commit_id'], cwd=ROOT, text=True).strip()
records = []
for observed, order in ((False, 'a'), (True, 'a'), (True, 'b'), (False, 'b')):
    name = f'{"observed" if observed else "plain"}-{order}'
    print(name, flush=True)
    context = HostActivity(OUT / f'{name}-activity.jsonl') if observed else nullcontext()
    with context:
        with (OUT / f'{name}.log').open('w') as log:
            process = subprocess.run([
                sys.executable, str(ROOT / 'tools/phase5/integration_profile.py'),
                '--case', 'public-fresh', '--workload', 'parameterized',
                '--iterations', '25000', '--samples', '3', '--revision', revision,
                '--output', str(OUT / f'{name}.json')], env=dict(os.environ),
                stdout=log, stderr=subprocess.STDOUT, timeout=90)
    records.append({'name': name, 'status': process.returncode})
    (OUT / 'order.json').write_text(json.dumps(records, indent=2)+'\n')
    if process.returncode:
        raise SystemExit(f'{name} failed: {process.returncode}')
