"""Audit the published main benchmark's complete raw worker evidence."""

import hashlib
import json
import math
from pathlib import Path
import statistics
import sys
import zipfile

ROOT = Path('/Users/martijnberger/src/psycopg')
sys.path.insert(0, str(ROOT / 'tools/phase5'))
from repeat_benchmark import server_identity, validate_report
from workloads import BENCHMARKS

BASE = Path('/tmp/phase5-public-boundary-main-benchmark')
DATA = BASE / 'home/runner/work/ferrocopg/ferrocopg'
REV = '12f139ce63a0c78d8148913673ef39392794e85f'
summary = json.loads((DATA / 'phase5-results/summary.json').read_text())
assert summary['revision'] == REV and summary['required_runs'] == 3
assert summary['performance_limits'] == {'python': 1.15, 'c': 1.5}
assert summary['performance_policy'] == 'beta-2026-09-20'
assert summary['benchmark_gate_passed'] and not summary['failures']
assert summary['runs'] == [{'report':f'run-{i}/report.json', 'failures':[]} for i in (1,2,3)]
wheel = BASE / 'tmp/phase5-wheels' / summary['identity']['wheel']
wheel_sha = hashlib.sha256(wheel.read_bytes()).hexdigest()
assert wheel_sha == summary['identity']['wheel_sha256']
assert wheel_sha == (DATA / 'phase5-wheel.sha256').read_text().split()[0]
with zipfile.ZipFile(wheel) as z:
    wheel_files = {name:hashlib.sha256(z.read(name)).hexdigest()
                   for name in z.namelist() if name.startswith('ferrocopg/') and not name.endswith('/')}
    with zipfile.ZipFile('/tmp/phase5-direct-outcome-final-wheels/ferrocopg-0.1.0-cp314-cp314-macosx_11_0_arm64.whl') as local:
        python_files = [name for name in wheel_files if name.endswith('.py')]
        assert python_files
        assert all(z.read(name) == local.read(name) for name in python_files)

runs = []
for number in (1,2,3):
    directory = DATA / f'phase5-results/run-{number}'
    report = json.loads((directory / 'report.json').read_text())
    assert validate_report(report, REV, 0) == []
    assert server_identity(report) == summary['environment']
    groups = {}
    for r in report['results']:
        backend, workload = r['backend'], r['workload']
        assert json.loads((directory / f'{workload}-{backend}.json').read_text()) == r
        assert not r['failures'] and r['cleanup']['sessions'] == 0
        assert r['metadata']['driver_file'].startswith('/tmp/phase5-env/lib/python3.14/site-packages/')
        for key in ('seconds', 'cpu_seconds'):
            assert len(r[key]) == 9
            assert all(math.isfinite(x) and x > 0 for x in r[key])
        latencies = r['operation_latency_ms']
        assert len(latencies) == 900 and all(math.isfinite(x) and x > 0 for x in latencies)
        ordered = sorted(latencies)
        assert r['latency_ms'] == {'p50':statistics.median(latencies),
                                   'p95':ordered[math.ceil(900*.95)-1],
                                   'p99':ordered[math.ceil(900*.99)-1]}
        assert all(sum(latencies[i*100:(i+1)*100])/1000 <= r['seconds'][i] for i in range(9))
        units = 2000 if workload.startswith('copy_') else 1000 if workload.startswith('rows_') else 1
        assert r['units_per_second'] == units*100/statistics.median(r['seconds'])
        groups.setdefault(workload, {})[backend] = r
    assert set(groups) == set(BENCHMARKS)
    metrics = {}
    ratios = {}
    for workload, rows in groups.items():
        assert set(rows) == {'rust', 'python', 'c'}
        medians = {b:statistics.median(r['seconds']) for b,r in rows.items()}
        ratios[workload] = {b:medians['rust']/medians[b] for b in ('python', 'c')}
        assert ratios[workload]['python'] <= 1.15 and ratios[workload]['c'] <= 1.5
        metrics[workload] = {
            b:{'wall_us_per_operation':medians[b]*1e4,
               'cpu_us_per_operation':statistics.median(r['cpu_seconds'])*1e4,
               'latency_ms':r['latency_ms'], 'units_per_second':r['units_per_second']}
            for b,r in rows.items()}
    assert ratios == report['ratios']
    runs.append({'run':number, 'ratios':ratios, 'metrics':metrics})

audit = {
    'workflow':'https://github.com/martijnberger/ferrocopg/actions/runs/36230544336',
    'artifact_id':10902059653, 'revision':REV, 'benchmark_job':'success',
    'soak_status_at_audit':'in_progress', 'independently_recomputed':True,
    'three_run_numeric_benchmark_gate_passed':True, 'phase5_complete':False,
    'validated_runs':3, 'validated_workers':99, 'validated_operation_latencies':89100,
    'summary':summary, 'wheel_package_file_sha256':wheel_files,
    'python_files_matching_local_measured_wheel':len(python_files), 'runs':runs,
    'measurement_limits':[
        'Dedicated GitHub-hosted runner; before/after process snapshots are not continuous host-idleness proof.',
        'Package identity is checked by the on-runner harness around each complete run; archived wheel digest independently matches.',
        'Passing these beta limits is not near parity or before/after attribution.',
        'Soak, compatibility, dedicated prototype comparison, outcome completion, and final audits remain incomplete.',
    ],
}
dest = ROOT / 'docs/performance/2026-09-26-public-boundary-three-run-benchmark.json'
dest.write_text(json.dumps(audit, indent=2) + '\n')
for work in BENCHMARKS:
    print(work, 'Python', [round(r['ratios'][work]['python'],4) for r in runs],
          'C', [round(r['ratios'][work]['c'],4) for r in runs])
print('WHEEL', wheel_sha, 'FILES', len(wheel_files), 'PYTHON', len(python_files))
