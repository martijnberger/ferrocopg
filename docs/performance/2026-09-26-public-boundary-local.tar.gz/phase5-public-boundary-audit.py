"""Independently inspect all scalar controls and sampled host activity."""

from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
import statistics
import zipfile

OUT = Path('/tmp/phase5-public-boundary-20260926')
manifest = json.loads((OUT / 'manifest.json').read_text())
reports = {}
identity = None
fingerprints = {}
for path in sorted(OUT.glob('integration-*.json')):
    r = json.loads(path.read_text())
    assert r['mode'] == 'integration-diagnostic' and not r['acceptance_evidence']
    assert r['iterations'] == 10000 and r['warmup'] == 1000
    assert r['binary'] and r['prepared'] and r['profile'] is None
    assert r['bookkeeping'] == 'normal' and not r['omitted_helper_bodies']
    assert len(r['samples']) == 9
    for k in ('wall_us', 'cpu_us'):
        values = [v[k] for v in r['samples']]
        assert all(math.isfinite(v) and v > 0 for v in values)
        assert r['medians_us'][k] == statistics.median(values)
    current = {k:r['metadata'][k] for k in ('python', 'platform', 'machine', 'server', 'server_settings')}
    if identity is None:
        identity = current
    assert identity == current
    variant = path.name.split('-')[1]
    expected_revision = manifest['revisions']['after' if variant == 'c' else variant]
    assert r['metadata']['revision'] == expected_revision
    assert r['backend'] == ('c' if variant == 'c' else 'rust')
    fp = r['installed_file_sha256']
    assert fp and all(files for files in fp.values())
    if variant not in fingerprints:
        fingerprints[variant] = fp
    assert fp == fingerprints[variant]
    if variant != 'c':
        wheel, digest = manifest['wheels'][variant]
        assert hashlib.sha256(Path(wheel).read_bytes()).hexdigest() == digest
        with zipfile.ZipFile(wheel) as z:
            for name, actual in fp['ferrocopg'].items():
                assert actual == hashlib.sha256(z.read(name)).hexdigest()
    reports[path.stem] = r
assert len(reports) == 24
workers = [json.loads(line) for line in (OUT / 'workers.jsonl').read_text().splitlines()]
assert len(workers) == 24 and all(w['returncode'] == 0 for w in workers)
assert len({w['label'] for w in workers}) == 24
assert all(a['ended'] <= b['started'] for a,b in zip(workers, workers[1:]))

pairs = {}
for case in ('public-fresh', 'public-reused'):
    for work in ('constant', 'parameterized'):
        label = f'{case}-{work}'
        controls = {position:reports[f'integration-c-{label}-{position}']['medians_us']
                    for position in ('start', 'end')}
        values = {}
        for position in ('a', 'b'):
            before = reports[f'integration-before-{label}-{position}']['medians_us']
            after = reports[f'integration-after-{label}-{position}']['medians_us']
            values[position] = {
                'before': before, 'after': after,
                'wall_saving_us': before['wall_us'] - after['wall_us'],
                'wall_saving_percent': (1-after['wall_us']/before['wall_us'])*100,
                'cpu_saving_percent': (1-after['cpu_us']/before['cpu_us'])*100,
                'after_over_c_wall': {p:after['wall_us']/c['wall_us'] for p,c in controls.items()},
            }
        pairs[label] = {'orders': values, 'c_controls': controls,
                       'c_end_over_start': {k:controls['end'][k]/controls['start'][k]
                                            for k in ('wall_us', 'cpu_us')}}

activity = [json.loads(line) for line in (OUT / 'host-activity.jsonl').read_text().splitlines()]
assert activity[-1]['status'] == 'completed'
intervals = [r for r in activity if 'elapsed_seconds' in r]
cpu = defaultdict(float)
system = defaultdict(float)
observed_builds = set()
for r in intervals:
    for k,v in r['system_cpu_seconds'].items():
        system[k] += v
    for p in r['active_processes']:
        cpu[p['name']] += p['interval_cpu_seconds']
        if p['name'].lower() in ('rustc', 'cargo', 'maturin', 'pytest'):
            observed_builds.add(p['name'])
elapsed = sum(r['elapsed_seconds'] for r in intervals)
summary = {
    'acceptance_evidence': False, 'validated_workers': 24, 'sequential_workers': True,
    'environment': identity, 'pairs': pairs,
    'host_activity': {
        'intervals': len(intervals), 'elapsed_seconds': elapsed,
        'largest_interval_seconds': max(r['elapsed_seconds'] for r in intervals),
        'observer_cpu_seconds': activity[-1]['observer_thread_cpu_seconds'],
        'observer_one_core_percent': activity[-1]['observer_thread_cpu_seconds']/elapsed*100,
        'system_cpu_seconds': dict(system),
        'system_busy_percent': (1-system['idle']/sum(system.values()))*100,
        'active_cpu_by_name': dict(sorted(cpu.items(), key=lambda item:-item[1])),
        'observed_active_build_test_processes': sorted(observed_builds),
        'maximum_unavailable_processes': max(r['unavailable_processes'] for r in intervals),
        'idle_host_proven': False,
        'limitations': activity[0]['limitations'],
    },
    'limitations': [
        'Local macOS development machine, not an idle dedicated runner.',
        'Scalar prepared binary queries only; no all-workload or tail-latency acceptance.',
        'C controls bracket the matrix; they are not randomized paired release comparisons.',
        'Before revision is the pre-public-integration control, not the accepted beta baseline.',
        'The result attributes the combined public integration, not each individual subchange.',
    ],
}
(OUT / 'audit.json').write_text(json.dumps(summary, indent=2) + '\n')
for label, r in pairs.items():
    print(label, json.dumps(r))
print('HOST', json.dumps({k:v for k,v in summary['host_activity'].items() if k != 'active_cpu_by_name'}))
print('TOP ACTIVITY', list(summary['host_activity']['active_cpu_by_name'].items())[:15])
