"""One frozen, sequential public-boundary diagnostic; not acceptance."""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/Users/martijnberger/src/psycopg')
sys.path.insert(0, str(ROOT / 'tools/phase5'))
from codegen_compare import compare_integration, comparison_order
from host_activity import HostActivity

OUT = Path('/tmp/phase5-public-boundary-20260926')
REVISIONS = {
    'before': 'd957b508785c9c304ad14f82b15fb3f598412cf3',
    'after': '12f139ce63a0c78d8148913673ef39392794e85f',
}
PYTHONS = {
    'before': '/tmp/phase5-before-integration-env/bin/python',
    'after': '/tmp/phase5-reservation-env/bin/python',
}
WHEELS = {
    'before': ('/tmp/phase5-reservation-wheels/ferrocopg-0.1.0-cp314-cp314-macosx_11_0_arm64.whl',
               '23634114127a3746ee1e6ae2b94625b6bad9dad45cda0a11a580f18eb1badd42'),
    'after': ('/tmp/phase5-direct-outcome-final-wheels/ferrocopg-0.1.0-cp314-cp314-macosx_11_0_arm64.whl',
              '1b8b361aa0bebcc57df7affad47c83bba575ac0a2e1981d2cedfff32123dae22'),
}
CASES = ('public-fresh', 'public-reused')
WORKLOADS = ('constant', 'parameterized')
OUT.mkdir(exist_ok=False)
env = dict(os.environ)
env.pop('PYTHONPATH', None)
env.pop('PSYCOPG_SOURCE_IMPL', None)
env['DYLD_LIBRARY_PATH'] = '/opt/homebrew/opt/postgresql@15/lib'
env['PHASE5_DSN'] = 'host=127.0.0.1 port=55436 dbname=phase5 user=martijnberger sslmode=disable'

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

for variant, (path, expected) in WHEELS.items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected
    verify = subprocess.run([
        PYTHONS[variant], '-c',
        'import hashlib, importlib.metadata as m, json, sys, zipfile; '
        'd=m.distribution("ferrocopg"); z=zipfile.ZipFile(sys.argv[1]); '
        'names=[n for n in z.namelist() if n.endswith((".py", ".so", ".pyd"))]; '
        'assert names; '
        'assert all(hashlib.sha256(z.read(n)).digest() == '
        'hashlib.sha256(d.locate_file(n).read_bytes()).digest() for n in names); '
        'print(json.dumps({"verified_files": len(names), "packages": '
        '{n:m.version(n) for n in ("ferrocopg", "psycopg", "psycopg-c", "psycopg-pool", "psutil")}}))',
        path], env=env, check=True, text=True, capture_output=True)
    write(f'installed-{variant}.json', json.loads(verify.stdout))

write('manifest.json', {
    'acceptance_evidence': False, 'revisions': REVISIONS,
    'python_environments': PYTHONS, 'wheels': WHEELS,
    'iterations': 10000, 'samples': 9, 'warmup': 1000,
    'order': [('c', 'start'), *comparison_order(list(REVISIONS)), ('c', 'end')],
    'harness_sha256': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                       for p in (ROOT / 'tools/phase5').glob('*.py')},
})
with (OUT / 'workers.jsonl').open('x') as workers, HostActivity(OUT / 'host-activity.jsonl'):
    for variant, position in [('c', 'start'), *comparison_order(list(REVISIONS)), ('c', 'end')]:
        source = 'after' if variant == 'c' else variant
        for case in CASES:
            for workload in WORKLOADS:
                label = f'integration-{variant}-{case}-{workload}-{position}'
                command = [PYTHONS[source], str(ROOT / 'tools/phase5/integration_profile.py'),
                           '--case', case, '--workload', workload,
                           '--backend', 'c' if variant == 'c' else 'rust',
                           '--revision', REVISIONS[source], '--iterations', '10000',
                           '--samples', '9', '--output', str(OUT / f'{label}.json')]
                started = time.time()
                print(f'START {label}', flush=True)
                with (OUT / f'{label}.log').open('x') as log:
                    result = subprocess.run(command, env=env, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
                workers.write(json.dumps({'label': label, 'command': command, 'started': started,
                                          'ended': time.time(), 'returncode': result.returncode}) + '\n')
                workers.flush()
                print(f'END {label}: {result.returncode}', flush=True)
                if result.returncode:
                    raise SystemExit(result.returncode)
write('comparison.json', compare_integration(OUT, REVISIONS, iterations=10000))
print('COMPLETE', flush=True)
