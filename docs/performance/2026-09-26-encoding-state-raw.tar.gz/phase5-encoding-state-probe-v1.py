"""Capture session-state correctness controls; no timing or production patches."""

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, "/Users/martijnberger/src/psycopg/tools/phase5")
from query_profile import installed_files
from run import driver_for, metadata


def case(driver, name, prepare):
    result = {"case": name, "prepare": prepare, "failures": []}
    with driver.connect(os.environ["PHASE5_DSN"], autocommit=True) as conn:
        conn.execute("create temporary table encoding_probe "
                     "(i int unique deferrable initially deferred)")
        conn.execute("begin")
        conn.execute("set local client_encoding to LATIN1")
        retained = conn.execute("select chr(233)")
        expected_encoding = "utf-8"
        expected_status = driver.pq.TransactionStatus.IDLE
        if name == "savepoint":
            conn.execute("savepoint encoding_savepoint")
            conn.execute("set local client_encoding to UTF8")
            expected_encoding = "iso8859-1"
            expected_status = driver.pq.TransactionStatus.INTRANS
        if name.startswith("failed"):
            conn.execute("insert into encoding_probe values (1),(1)")
        statements = {
            "commit": "commit",
            "rollback": "rollback",
            "commented-commit": "/* finish */ commit",
            "commented-rollback": "/* finish */ rollback",
            "end": "end",
            "abort": "abort",
            "savepoint": "/* recover */ rollback to encoding_savepoint",
            "failed-commit": "commit",
            "failed-commented-commit": "/* finish */ commit",
        }
        error = None
        try:
            if name in {"method-commit", "failed-method-commit"}:
                conn.commit()
            elif name == "method-rollback":
                conn.rollback()
            else:
                conn.execute(statements[name], prepare=prepare)
        except driver.Error as exc:
            error = {"type": type(exc).__name__, "sqlstate": exc.sqlstate}
        result["boundary_error"] = error
        if (error and error["sqlstate"]) != ("23505" if name.startswith("failed") else None):
            result["failures"].append("unexpected boundary error")
        result["public_encoding"] = conn.info.encoding
        result["transaction_status"] = int(conn.info.transaction_status)
        result["expected_encoding"] = expected_encoding
        result["expected_transaction_status"] = int(expected_status)
        if conn.info.encoding != expected_encoding:
            result["failures"].append("stale public encoding")
        if conn.info.transaction_status != expected_status:
            result["failures"].append("wrong transaction status")
        result["retained_row"] = retained.fetchone()
        if result["retained_row"] != ("\u00e9",):
            result["failures"].append("retained result encoding changed")
        # ASCII-only queries avoid triggering the Rust UTF8 query-text bridge.
        result["server_encoding"] = conn.execute("show client_encoding").fetchone()[0]
        result["public_encoding_after_show"] = conn.info.encoding
        try:
            result["next_row"] = conn.execute("select chr(233)").fetchone()
            if result["next_row"] != ("\u00e9",):
                result["failures"].append("incorrect returned text")
        except Exception as exc:
            result["next_row_error"] = {"type": type(exc).__name__, "message": str(exc)}
            result["failures"].append("returned text cannot be decoded")
        if conn.info.transaction_status != driver.pq.TransactionStatus.IDLE:
            conn.rollback()
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--backend", choices=("rust", "c"), required=True)
    parser.add_argument("--revision", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        parser.error("refusing to replace existing evidence")
    os.environ["PSYCOPG_IMPL"] = "python" if args.backend == "rust" else "c"
    driver = driver_for(args.backend)
    cases = ("commit", "rollback", "commented-commit", "commented-rollback",
             "end", "abort", "savepoint", "failed-commit", "failed-commented-commit",
             "method-commit", "method-rollback", "failed-method-commit")
    with driver.connect(os.environ["PHASE5_DSN"], autocommit=True) as observer:
        environment = metadata(driver, observer, args)
    distribution = "ferrocopg" if args.backend == "rust" else "psycopg"
    fingerprints = {distribution: installed_files(distribution)}
    if args.backend == "c":
        fingerprints["psycopg-c"] = installed_files("psycopg-c")
    results = [case(driver, name, prepare) for prepare in (False, True) for name in cases]
    report = {
        "backend": args.backend,
        "metadata": environment,
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "installed_file_sha256": fingerprints,
        "results": results,
        "failed_cases": sum(bool(result["failures"]) for result in results),
    }
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"backend": args.backend, "cases": len(results),
                      "failed_cases": report["failed_cases"]}))
    return int(bool(report["failed_cases"]))


if __name__ == "__main__":
    raise SystemExit(main())
