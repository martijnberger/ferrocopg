#include <assert.h>
#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <time.h>

static double seconds(void) {
    struct timespec now;
    assert(clock_gettime(CLOCK_MONOTONIC, &now) == 0);
    return now.tv_sec + now.tv_nsec / 1e9;
}

static void *measure(void *label) {
    pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
    pthread_cond_t condition = PTHREAD_COND_INITIALIZER;
    const char *names[] = {"nanosleep", "condition_relative", "condition_absolute"};
    for (int order = 0; order < 2; order++) {
        for (int index = 0; index < 3; index++) {
            int method = order ? 2 - index : index;
            for (int delay = 10; delay <= 100; delay *= 10) {
                for (int sample = 0; sample < 5; sample++) {
                    struct timespec interval = {0, delay * 1000000L};
                    struct timespec deadline;
                    assert(clock_gettime(CLOCK_REALTIME, &deadline) == 0);
                    deadline.tv_nsec += interval.tv_nsec;
                    if (deadline.tv_nsec >= 1000000000L) {
                        deadline.tv_sec++;
                        deadline.tv_nsec -= 1000000000L;
                    }
                    double begin = seconds();
                    int result;
                    if (method == 0) {
                        result = nanosleep(&interval, NULL);
                        assert(result == 0);
                    } else {
                        assert(pthread_mutex_lock(&lock) == 0);
                        if (method == 1) {
                            result = pthread_cond_timedwait_relative_np(
                                &condition, &lock, &interval);
                        } else {
                            result = pthread_cond_timedwait(&condition, &lock, &deadline);
                        }
                        assert(pthread_mutex_unlock(&lock) == 0);
                        assert(result == ETIMEDOUT);
                    }
                    double elapsed = seconds() - begin;
                    printf("%s,%d,%s,%d,%d,%.9f\n", (char *)label, order,
                           names[method], delay, sample, elapsed);
                }
            }
        }
    }
    assert(pthread_cond_destroy(&condition) == 0);
    assert(pthread_mutex_destroy(&lock) == 0);
    return NULL;
}

int main(void) {
    printf("thread,order,wait,delay_ms,sample,seconds\n");
    measure("main");
    pthread_t thread;
    assert(pthread_create(&thread, NULL, measure, "worker") == 0);
    assert(pthread_join(thread, NULL) == 0);
    return 0;
}
