"""Summarize all driver-free timing observations without selecting samples."""
import csv
import json
from pathlib import Path
import statistics

BASE = Path('/tmp')
reports = {}
for name in ('default', 'homebrew314', 'latency0', 'latency1'):
    report = json.loads((BASE / f'phase5-timer-{name}.json').read_text())
    groups = []
    for row in report['results']:
        values = row['seconds']
        assert len(values) == 5
        assert all(value >= row['delay'] for value in values)
        groups.append({'thread': row['thread'], 'order': row['order'],
                       'wait': row['wait'], 'delay_ms': row['delay'] * 1000,
                       'median_overshoot_ms': (statistics.median(values)-row['delay'])*1000,
                       'max_overshoot_ms': (max(values)-row['delay'])*1000,
                       'over_5ms': sum(value-row['delay'] > .005 for value in values),
                       'over_10ms': sum(value-row['delay'] > .01 for value in values)})
    reports[name] = {'python': report['python'], 'platform': report['platform'],
                     'groups': groups, 'samples': sum(len(r['seconds']) for r in report['results'])}
for name, filename in [('native', 'phase5-timer-native.csv'),
                       ('native-latency0', 'phase5-timer-native-latency0.csv')]:
    rows = list(csv.DictReader((BASE / filename).open()))
    data = {}
    for row in rows:
        key = (row['thread'], row['order'], row['wait'], int(row['delay_ms']))
        data.setdefault(key, []).append(float(row['seconds']))
    groups = []
    for (thread, order, wait, delay_ms), values in data.items():
        delay = delay_ms/1000
        assert len(values) == 5 and all(value >= delay for value in values)
        groups.append({'thread': thread, 'order': order, 'wait': wait,
                       'delay_ms': delay_ms,
                       'median_overshoot_ms': (statistics.median(values)-delay)*1000,
                       'max_overshoot_ms': (max(values)-delay)*1000,
                       'over_5ms': sum(value-delay > .005 for value in values),
                       'over_10ms': sum(value-delay > .01 for value in values)})
    reports[name] = {'groups': groups, 'samples': len(rows)}
result = {'acceptance_evidence': False, 'reports': reports,
          'limitations': [
              'Each condition has only five observations; this is mechanism diagnosis, not stable tail estimation.',
              'No continuous host-idleness measurement; no database driver imported by either probe.',
              'The native-latency0 process was not confirmed terminal before starting Python latency1; those two exploratory controls may overlap.',
              'Latency-policy options were process-scoped only; no change was made to the machine or parent process.',
              'Returned task_policy_get values do not establish an effective policy change; no successful remedy is claimed.',
              'Raw complete compatibility failure and its strict gate remain failed.'
          ]}
Path('/Users/martijnberger/src/psycopg/docs/performance/2026-09-26-host-timer-diagnostic.json').write_text(
    json.dumps(result, indent=2)+'\n')
for name, report in reports.items():
    groups = [g for g in report['groups'] if g['delay_ms'] == 100]
    print(name, 'samples', report['samples'], '100ms group median overshoot range',
          round(min(g['median_overshoot_ms'] for g in groups), 3),
          round(max(g['median_overshoot_ms'] for g in groups), 3),
          'over5ms', sum(g['over_5ms'] for g in groups),
          'over10ms', sum(g['over_10ms'] for g in groups), 'of', len(groups)*5)
