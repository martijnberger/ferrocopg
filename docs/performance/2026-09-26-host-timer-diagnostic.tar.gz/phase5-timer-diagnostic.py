"""Driver-free timer controls; diagnostic only, never compatibility acceptance."""

import argparse
import ctypes
import json
import platform
import statistics
import sys
import threading
import time

parser = argparse.ArgumentParser()
parser.add_argument('--qos', type=int)
args = parser.parse_args()
lib = ctypes.CDLL('/usr/lib/libSystem.B.dylib')
lib.pthread_self.restype = ctypes.c_void_p
lib.pthread_get_qos_class_np.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint),
                                       ctypes.POINTER(ctypes.c_int)]
lib.pthread_set_qos_class_self_np.argtypes = [ctypes.c_uint, ctypes.c_int]
lib.mach_task_self.restype = ctypes.c_uint
lib.task_policy_get.argtypes = [ctypes.c_uint, ctypes.c_int, ctypes.POINTER(ctypes.c_int),
                               ctypes.POINTER(ctypes.c_uint), ctypes.POINTER(ctypes.c_int)]

def task_policy(flavor, size):
    values = (ctypes.c_int * size)()
    count, default = ctypes.c_uint(size), ctypes.c_int(0)
    result = lib.task_policy_get(lib.mach_task_self(), flavor, values,
                                 ctypes.byref(count), ctypes.byref(default))
    return {'return_code': result, 'count': count.value,
            'default': default.value, 'values': list(values)}

def qos():
    value, priority = ctypes.c_uint(), ctypes.c_int()
    result = lib.pthread_get_qos_class_np(lib.pthread_self(), ctypes.byref(value),
                                         ctypes.byref(priority))
    assert result == 0, result
    return {'class': value.value, 'relative_priority': priority.value}

results = []
errors = []
def measure(label):
    try:
        initial = qos()
        if args.qos is not None:
            result = lib.pthread_set_qos_class_self_np(args.qos, 0)
            assert result == 0, result
        effective = qos()
        event = threading.Event()
        lock = threading.Lock()
        lock.acquire()
        waits = {'sleep': time.sleep, 'event': event.wait,
                 'lock': lambda timeout: lock.acquire(timeout=timeout)}
        for order in ('forward', 'reverse'):
            names = list(waits) if order == 'forward' else list(reversed(waits))
            for name in names:
                for delay in (0.01, 0.1):
                    samples = []
                    for _ in range(5):
                        start = time.perf_counter_ns()
                        outcome = waits[name](delay)
                        duration = (time.perf_counter_ns() - start) / 1e9
                        assert outcome is None or outcome is False
                        samples.append(duration)
                    results.append({'thread': label, 'initial_qos': initial,
                                    'requested_qos': args.qos, 'actual_qos': effective,
                                    'order': order, 'wait': name, 'delay': delay,
                                    'seconds': samples,
                                    'median_overshoot_ms': (statistics.median(samples)-delay)*1000})
    except BaseException as error:
        errors.append(repr(error))

measure('main')
thread = threading.Thread(target=measure, args=('worker',))
thread.start()
thread.join(30)
assert not thread.is_alive()
assert not errors, errors
print(json.dumps({'python': sys.version, 'executable': sys.executable,
                  'platform': platform.platform(), 'switch_interval': sys.getswitchinterval(),
                  'task_base_qos': task_policy(8, 2),
                  'task_override_qos': task_policy(9, 2),
                  'task_category': task_policy(1, 1),
                  'no_database_or_driver_imported': True, 'results': results}, indent=2))
